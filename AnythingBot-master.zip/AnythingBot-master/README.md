# AnythingBot - Gags

### Feeling Lazy, to type, press the mic, and start talking and it talks back ! :D
### Say, "Hey" to wake the bot !

## Things it can do !
![main_page](main.png)
### Now, know weather of any city in the world , just say, "Weather in Mumbai" or any city of your choice ! :D
![weather](weather.png)
### Also, it can calculate ! Give it any calculation ! example of how you can "tell me what is 5 into 6" . For calculations having numbers above 100, while saying it , for example, 102 + 4, say it as "one zero two plus four".
![math](math.png)
### Search for any video you want ! just say, "show me video (name of video)" or just, "search videos of (whatever you want)", that's it ! :D
![vids1](vids1.png)
### Search for songs, now search for anything ! Google integrated ! :D
### Get Directions immidiately ! just mention from where to where ! Eg: "give me the directions from borivali to malad".
![dir](dir.png)


### Will add more interesting things soon, you could even contribute add interesting replies and add things which the bot can answer to ! :D
